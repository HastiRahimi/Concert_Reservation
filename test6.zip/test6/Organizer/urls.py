from django.urls import path
from . import views
from .views import event_list, event_detail, organizer_profile


urlpatterns = [
    path("", views.Participant_detail, name="index"),
    path("home/", views.Participant_detail, name="index"),


    path('events/', event_list, name='event_list'),
    path('events/<int:event_id>/', event_detail, name='event_detail'),
    path('profile/', organizer_profile, name='organizer_profile'),
]
