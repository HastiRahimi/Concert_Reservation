from django.http import HttpResponse
from django.shortcuts import render, get_object_or_404
from .models import Participant, Events, OrganizerProfile


def Participant_detail(request, Participant_id):
    Participant_id = Participant.objects.get(pk=Participant_id),
    return HttpResponse(f"Hello my dear member with id: {Participant_id}. you are at the ParticipatingUser index.")



def event_list(request):
    events = Events.objects.filter(organizer=request.user)
    return render(request, 'organizer/event_list.html', {'events': events})

def event_detail(request, event_id):
    event = get_object_or_404(Events, pk=event_id, organizer=request.user)
    return render(request, 'organizer/event_detail.html', {'event': event})

def organizer_profile(request):
    profile = get_object_or_404(OrganizerProfile, user=request.user)
    return render(request, 'organizer/organizer_profile.html', {'profile': profile})
