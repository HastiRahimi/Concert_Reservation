from django.db import models


class Participant(models.Model):
    First_Name = models.CharField(null=True, max_length=200),
    Last_Name = models.CharField(null=True, max_length=200),
    Email = models.EmailField(null=True, max_length=200),
    Phone_Number = models.CharField(null=True, max_length=200)
    password = models.CharField(null=True, max_length=8),

class Login(models.Model):
    User_Name = models.CharField(null=True, max_length=200),
    password = models.CharField(null=True, max_length=8),



class Events(models.Model):
    name = models.CharField(max_length=255)
    venue = models.CharField(max_length=255)
    date = models.DateTimeField()
    registration_fee = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return self.name



class OrganizerProfile(models.Model):
    description = models.TextField()


    def __str__(self):
        return self.user.username
