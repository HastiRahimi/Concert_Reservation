from django.db import models


class Login(models.Model):
    User_Name = models.CharField(null=True, max_length=200),
    password = models.CharField(null=True, max_length=8),


class Events(models.Model):
    name = models.CharField(max_length=255)
    venue = models.CharField(max_length=255)
    date = models.DateTimeField()
    registration_fee = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return self.name



class Participant(models.Model):
    First_Name = models.CharField(null=True, max_length=200),
    Last_Name = models.CharField(null=True, max_length=200),
    Email = models.EmailField(null=True, max_length=200),
    password = models.CharField(null=True, max_length=8),
    event = models.ForeignKey(Events, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.user.username} - {self.event.name}"



