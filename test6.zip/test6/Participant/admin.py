from django.contrib import admin
from .models import Login, Participant, Events

admin.site.register(Login),
admin.site.register(Participant),
admin.site.register(Events)
