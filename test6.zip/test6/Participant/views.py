from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse

import Participant
from .models import Events, Participant

def index(request):
    return HttpResponse("you are at the ParticipatingUser index.")
def __str__(self):
    return self.title


def event_list(request):
    events = Events.objects.all()
    return render(request, 'participants/event_list.html', {'events': events})

def event_detail(request, event_id):
    event = get_object_or_404(Events, pk=event_id)
    return render(request, 'participants/event_detail.html', {'event': event})

def participant_list(request):
    participants = Participant.objects.all()
    return render(request, 'participants/participant_list.html', {'participants': participants})

def participant_detail(request, participant_id):
    participant = get_object_or_404(Participant, pk=participant_id)
    return render(request, 'participants/participant_detail.html', {'participant': participant})
