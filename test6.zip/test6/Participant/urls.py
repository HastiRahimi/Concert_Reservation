from django.urls import path
from . import views
from .views import event_list, event_detail, participant_list, participant_detail

urlpatterns = [
    path("", views.index, name="index"),
    path("home/", views.index, name="index"),


    path('events/', event_list, name='event_list'),
    path('events/<int:event_id>/', event_detail, name='event_detail'),
    path('participants/', participant_list, name='participant_list'),
    path('participants/<int:participant_id>/', participant_detail, name='participant_detail'),

]